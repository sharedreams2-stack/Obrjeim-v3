package com.oberjein.synth

import kotlin.math.roundToInt

/** Names of the enumerated params. Counts must match kModes/kRates/... in cpp/arp.h. */
object Names {
    val MODES = listOf("Up", "Down", "Up-Down", "Down-Up", "Up&Down", "Converge", "Diverge", "Order", "Random", "Walk", "Thumb", "Pinky", "Chord")
    val RATES = listOf("1/2", "1/4", "1/8.", "1/8", "1/16.", "1/8T", "1/16", "1/16T", "1/32", "1/32T")
    val CHORDS = listOf("Off", "Oct", "5th", "Power", "Major", "Minor", "Sus2", "Sus4", "Maj7", "Min7", "Dom7", "Add9", "Scale 3", "Scale 4", "Scale 5")
    val SCALES = listOf(
        "Chromatic", "Major", "Minor", "Harm minor", "Mel minor", "Dorian", "Phrygian", "Lydian",
        "Mixolydian", "Locrian", "Pent major", "Pent minor", "Blues", "Whole tone", "Dim W-H"
    )
    val STRUM_DIRS = listOf("Up", "Down", "Alt", "Random")
    val ROOTS = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    val LFO_SHAPES = listOf("Sine", "Tri", "Saw", "Square", "S&H")
    val CLOCK = listOf("Internal", "MIDI clock")
    val FILTER_TYPES = listOf("Ladder", "LP 12", "LP 24", "Band", "High", "Notch", "Off")
    val ROUTES = listOf("Serial", "Parallel")
    val WT_BANKS = listOf("Basic", "Vocal", "Spectral", "Metal")
    val CHANNELS = (1..16).map { "Ch $it" }
    val IN_CHANNELS = listOf("Omni") + CHANNELS
}

fun enumValue(index: Int, count: Int): Float = index / (count - 1).toFloat()
fun enumIndex(v: Float, count: Int): Int = (v * (count - 1)).roundToInt().coerceIn(0, count - 1)

/** Mod sources; index = slot value sent to the DSP (see enum in synth.h). 0 means "off". */
val MOD_SOURCES = listOf(
    "Off", "LFO 1", "LFO 2", "Random/step", "Lane mod", "Mod wheel", "Velocity", "Key",
    "Macro 1", "Macro 2", "Macro 3", "Macro 4"
)
const val MOD_SLOTS = 8

/** Normalized defaults for every parameter. */
val DEFAULTS: FloatArray = FloatArray(P.COUNT) { PARAM_INFO[it].default }

/** Human readable value for the knob read-out. */
fun formatParam(id: Int, v: Float): String = when (id) {
    P.ARP_BPM -> "${(30 + 270 * v).roundToInt()} bpm"
    P.ARP_LEN -> "${1 + (v * 63).roundToInt()} steps"
    P.ARP_RATCH -> "x${1 + (v * 7).roundToInt()}"
    P.ARP_OCT -> "${1 + (v * 3).roundToInt()} oct"
    P.ARP_SHIFT -> "%+d deg".format(((v - 0.5f) * 24).roundToInt())
    P.ARP_SHIFT_CYCLE -> "%+d deg".format(((v - 0.5f) * 14).roundToInt())
    P.ARP_GATE -> "${((0.05f + 0.95f * v) * 100).roundToInt()}%"
    P.ARP_VEL -> "${((0.5f + v) * 100).roundToInt()}%"
    P.EVO_RATE -> "${1 + (v * 15).roundToInt()} cycles"
    P.RND_RANGE -> "+-${1 + (v * 23).roundToInt()} deg"
    P.O3_SEMI -> "%+d st".format(((v - 0.5f) * 48).roundToInt())
    P.O3_DETUNE -> "%+d ct".format(((v - 0.5f) * 100).roundToInt())
    P.F1_OFFSET, P.F2_OFFSET, P.AENV_OFFSET -> "%+d%%".format(((v - 0.5f) * 200).roundToInt())
    P.BEND_RANGE -> "+-${1 + (v * 23).roundToInt()} st"
    P.MASTER_TUNE -> "%+d ct".format(((v - 0.5f) * 200).roundToInt())
    else -> "${(v * 100).roundToInt()}%"
}

/** Sound presets only touch the voice/filter/envelope/LFO params; arp, mod matrix and MIDI settings stay as they are. */
fun isSoundParam(id: Int) = id <= P.VOLUME || id == P.LFO2_RATE || id == P.LFO2_WAVE || id in P.O3_LEVEL..P.GLIDE_POLY

class Preset(val name: String, val values: FloatArray)

private fun preset(name: String, vararg changes: Pair<Int, Float>): Preset {
    val v = DEFAULTS.copyOf()
    changes.forEach { (id, x) -> v[id] = x }
    return Preset(name, v)
}

val PRESETS: List<Preset> = listOf(
    preset("Init"),
    preset("Brass",
        P.VCO2_DETUNE to 0.53f, P.CUTOFF to 0.35f, P.RESO to 0.1f, P.FENV_AMT to 0.55f,
        P.F_A to 0.35f, P.F_D to 0.5f, P.F_S to 0.5f, P.F_R to 0.35f,
        P.A_A to 0.3f, P.A_S to 0.85f, P.A_R to 0.35f),
    preset("Poly pad",
        P.VCO1_PULSE to 1f, P.PWM to 0.5f, P.LFO_PWM to 0.5f, P.LFO_RATE to 0.2f,
        P.CUTOFF to 0.5f, P.FENV_AMT to 0.2f, P.F_A to 0.75f, P.F_S to 0.7f,
        P.A_A to 0.75f, P.A_S to 0.9f, P.A_R to 0.8f),
    preset("Fat bass",
        P.VCO1_PULSE to 1f, P.VCO2_DETUNE to 0.52f, P.CUTOFF to 0.3f, P.RESO to 0.3f, P.FENV_AMT to 0.6f,
        P.F_A to 0.02f, P.F_D to 0.4f, P.F_S to 0.1f, P.A_A to 0.02f, P.A_S to 0.9f, P.A_R to 0.2f),
    preset("Sync lead",
        P.SYNC to 1f, P.VCO2_SEMI to 0.8f, P.LFO_PITCH to 0.15f, P.LFO_RATE to 0.45f,
        P.PORTA to 0.35f, P.UNISON to 1f, P.UNI_DETUNE to 0.25f, P.CUTOFF to 0.7f, P.FENV_AMT to 0.4f),
    preset("Strings",
        P.VCO2_DETUNE to 0.56f, P.POLES to 0f, P.CUTOFF to 0.55f, P.FENV_AMT to 0.1f,
        P.A_A to 0.65f, P.A_S to 0.9f, P.A_R to 0.7f, P.LFO_PWM to 0f),
    preset("Pluck",
        P.VCO1_SAW to 0f, P.VCO1_PULSE to 1f, P.PWM to 0.4f, P.CUTOFF to 0.3f, P.RESO to 0.35f, P.FENV_AMT to 0.7f,
        P.F_D to 0.35f, P.F_S to 0f, P.A_D to 0.4f, P.A_S to 0f, P.A_R to 0.3f),
    preset("Sweep fx",
        P.NOISE to 0.5f, P.RESO to 0.7f, P.LFO_FILTER to 0.6f, P.LFO_RATE to 0.15f, P.CUTOFF to 0.5f,
        P.A_A to 0.8f, P.A_S to 1f, P.A_R to 0.8f),
    preset("Arp pluck",
        P.VCO1_SAW to 0f, P.VCO1_PULSE to 1f, P.PWM to 0.35f, P.CUTOFF to 0.35f, P.RESO to 0.3f, P.FENV_AMT to 0.65f,
        P.F_D to 0.3f, P.F_S to 0.05f, P.A_D to 0.35f, P.A_S to 0.1f, P.A_R to 0.25f),
)

/** Arp presets reset every arp/random/evolve param (except on/hold) to default, then apply the changes. */
class ArpPreset(val name: String, val changes: List<Pair<Int, Float>>)

fun isArpParam(id: Int) = id in P.ARP_MODE..P.EVO_DRIFT

val ARP_PRESETS: List<ArpPreset> = listOf(
    ArpPreset("Classic up", emptyList()),
    ArpPreset("Trance gate", listOf(
        P.ARP_MODE to enumValue(4, Names.MODES.size), P.ARP_OCT to 1f / 3f, P.ARP_GATE to 0.3f,
        P.ARP_SCALE to enumValue(2, Names.SCALES.size), P.ARP_QUANT to 1f)),
    ArpPreset("Strum pad", listOf(
        P.ARP_MODE to 1f, P.ARP_RATE to enumValue(1, Names.RATES.size), P.ARP_CHORD to enumValue(13, Names.CHORDS.size),
        P.ARP_STRUM to 0.7f, P.ARP_GATE to 0.9f, P.ARP_SCALE to enumValue(1, Names.SCALES.size))),
    ArpPreset("Ratchet stutter", listOf(
        P.ARP_RATE to enumValue(3, Names.RATES.size), P.ARP_RATCH to 3f / 7f, P.ARP_RATCH_PROB to 0.5f,
        P.ARP_SWING to 0.3f, P.ARP_HUMAN to 0.2f)),
    ArpPreset("Evolving random", listOf(
        P.ARP_MODE to enumValue(8, Names.MODES.size), P.ARP_LEN to 1f, P.ARP_OCT to 2f / 3f,
        P.ARP_SCALE to enumValue(11, Names.SCALES.size), P.ARP_QUANT to 1f, P.RND_DENSITY to 0.7f, P.RND_RANGE to 0.35f,
        P.EVO_ON to 1f, P.EVO_AMT to 0.2f, P.EVO_RATE to 0.2f, P.EVO_DRIFT to 0.6f)),
)
