package com.oberjein.synth.ui

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/**
 * Vertical wheel (value 0..1, top = 1). The pitch wheel springs back to the center (0.5) on release;
 * the mod wheel stays where you leave it.
 */
@Composable
fun Wheel(label: String, tint: Color, springBack: Boolean, onChange: (Float) -> Unit, modifier: Modifier = Modifier, initial: Float = if (springBack) 0.5f else 0f) {
    var value by remember { mutableFloatStateOf(initial) }
    val cb by rememberUpdatedState(onChange)
    val scope = rememberCoroutineScope()
    val glow = LocalGlow.current
    Column(modifier.width(46.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier.weight(1f).width(40.dp).pointerInput(springBack) {
                detectVerticalDragGestures(
                    onDragEnd = { if (springBack) scope.launch { animate(value, 0.5f, animationSpec = spring(dampingRatio = 0.6f, stiffness = 300f)) { v, _ -> value = v; cb(v) } } },
                    onDragCancel = { if (springBack) { value = 0.5f; cb(0.5f) } },
                ) { change, dragAmount ->
                    change.consume()
                    value = (value - dragAmount / size.height * 1.15f).coerceIn(0f, 1f)
                    cb(value)
                }
            }
        ) {
            val r = CornerRadius(8.dp.toPx())
            drawRoundRect(Color.Black, Offset.Zero, size, r)                                   // slot
            val pad = 3.dp.toPx()
            val w = Size(size.width - 2 * pad, size.height - 2 * pad)
            // cylinder shading across the width
            drawRoundRect(
                Brush.horizontalGradient(listOf(Color(0xFF17181B), Color(0xFF6B6E78), Color(0xFFA2A5AE), Color(0xFF6B6E78), Color(0xFF17181B))),
                Offset(pad, pad), w, CornerRadius(6.dp.toPx())
            )
            // ridges scroll with the value so the wheel looks like it turns
            val step = 7.dp.toPx()
            val off = (value * 600f) % step
            var y = pad + off - step
            while (y < size.height - pad) {
                if (y > pad) drawLine(Color(0x66000000), Offset(pad + 2f, y), Offset(size.width - pad - 2f, y), 1.6.dp.toPx())
                if (y + 1.6.dp.toPx() > pad) drawLine(Color(0x33FFFFFF), Offset(pad + 2f, y + 2f), Offset(size.width - pad - 2f, y + 2f), 1f)
                y += step
            }
            // position marker
            val my = pad + (1f - value) * (size.height - 2 * pad)
            if (glow > 0.01f) drawRect(tint.copy(alpha = 0.3f * glow), Offset(pad, my - 4.dp.toPx()), Size(w.width, 8.dp.toPx()))
            drawRect(tint, Offset(pad, my - 1.2.dp.toPx()), Size(w.width, 2.4.dp.toPx()))
        }
        Text(label, fontSize = 9.sp, color = Dim, modifier = Modifier.padding(top = 2.dp))
    }
}
