package com.oberjein.synth.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.oberjein.synth.Names
import com.oberjein.synth.P
import com.oberjein.synth.SynthViewModel
import kotlinx.coroutines.delay

private val TABS = listOf("SOUND", "ARP", "MOD", "PATCHES", "SETTINGS")

@Composable
fun MainScreen(vm: SynthViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    CompositionLocalProvider(LocalGlow provides vm.ui.glow) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF17181B), Chassis))).safeDrawingPadding()) {
            Column(Modifier.fillMaxSize()) {
                TopBar(vm)
                TabBar(vm, tab) { tab = it }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (tab) {
                        0 -> SoundTab(vm)
                        1 -> ArpTab(vm)
                        2 -> ModTab(vm)
                        3 -> PatchesTab(vm)
                        else -> SettingsTab(vm)
                    }
                }
                KeyboardDock(vm)
            }
            vm.message?.let { msg ->
                LaunchedEffect(msg) { delay(2500); if (vm.message == msg) vm.message = null }
                Box(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 150.dp)
                        .relief(RoundedCornerShape(8.dp), FaceTop, FaceBottom).padding(horizontal = 16.dp, vertical = 8.dp)
                ) { Text(msg, color = Cream, fontSize = 13.sp) }
            }
        }
    }
}

@Composable
private fun TabBar(vm: SynthViewModel, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF26282C), Color(0xFF121314))))) {
        TABS.forEachIndexed { i, t ->
            val arpLive = i == 1 && vm.values[P.ARP_ON] > 0.5f
            val sel = i == selected
            Column(
                Modifier.weight(1f).clickable { onSelect(i) }.padding(top = 7.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (i == 1) { Led(arpLive, Mint, 7.dp); Spacer(Modifier.width(5.dp)) }
                    Text(t, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (sel) Amber else Dim)
                }
                Box(
                    Modifier.padding(top = 6.dp).fillMaxWidth().height(3.dp)
                        .glow(Amber, if (sel) vm.ui.glow * 0.8f else 0f, 6.dp, 1.dp)
                        .background(if (sel) Amber else Color.Transparent)
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SoundTab(vm: SynthViewModel) {
    FlowRow(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 4.dp)) {
        Section("Oscillator 1", Amber) {
            T(vm, P.VCO1_SAW, "Saw"); T(vm, P.VCO1_PULSE, "Pulse"); K(vm, P.VCO1_LEVEL, "Level")
        }
        Section("Oscillator 2", Amber) {
            T(vm, P.VCO2_SAW, "Saw"); T(vm, P.VCO2_PULSE, "Pulse"); K(vm, P.VCO2_LEVEL, "Level")
            K(vm, P.VCO2_SEMI, "Semitone"); K(vm, P.VCO2_DETUNE, "Detune"); T(vm, P.SYNC, "Sync")
        }
        Section("Osc 3 wavetable", Rose) {
            E(vm, P.O3_BANK, Names.WT_BANKS, "Bank"); K(vm, P.O3_LEVEL, "Level"); K(vm, P.O3_POS, "Position")
            K(vm, P.O3_SEMI, "Semitone"); K(vm, P.O3_DETUNE, "Detune")
        }
        Section("Mixer", Amber) { K(vm, P.PWM, "Pulse width"); K(vm, P.NOISE, "Noise") }
        Section("Filter 1", Ember) {
            E(vm, P.F1_TYPE, Names.FILTER_TYPES, "Type"); K(vm, P.CUTOFF, "Cutoff"); K(vm, P.RESO, "Resonance")
            K(vm, P.F1_DRIVE, "Drive"); K(vm, P.F1_FB, "Feedback"); K(vm, P.FENV_AMT, "Env amount")
            K(vm, P.KEYTRACK, "Key track"); T(vm, P.POLES, "24 dB")
        }
        Section("Filter 1 env", Teal) {
            K(vm, P.F_A, "Attack"); K(vm, P.F_D, "Decay"); K(vm, P.F_S, "Sustain"); K(vm, P.F_R, "Release")
            T(vm, P.F1_LOOP, "Loop"); K(vm, P.F1_OFFSET, "Offset")
        }
        Section("Filter 2", Ember) {
            E(vm, P.F2_TYPE, Names.FILTER_TYPES, "Type"); E(vm, P.FILT_ROUTE, Names.ROUTES, "Routing")
            K(vm, P.F2_CUTOFF, "Cutoff"); K(vm, P.F2_RESO, "Resonance")
            K(vm, P.F2_DRIVE, "Drive"); K(vm, P.F2_FB, "Feedback"); K(vm, P.F2_ENV_AMT, "Env amount"); K(vm, P.F2_KEYTRACK, "Key track")
        }
        Section("Filter 2 env", Teal) {
            K(vm, P.F2_A, "Attack"); K(vm, P.F2_D, "Decay"); K(vm, P.F2_S, "Sustain"); K(vm, P.F2_R, "Release")
            T(vm, P.F2_LOOP, "Loop"); K(vm, P.F2_OFFSET, "Offset")
        }
        Section("Amp envelope", Teal) {
            K(vm, P.A_A, "Attack"); K(vm, P.A_D, "Decay"); K(vm, P.A_S, "Sustain"); K(vm, P.A_R, "Release"); K(vm, P.AENV_OFFSET, "Offset")
        }
        Section("LFO 1", Iris) {
            E(vm, P.LFO_WAVE, Names.LFO_SHAPES, "Shape", width = 70.dp); K(vm, P.LFO_RATE, "Rate")
            K(vm, P.LFO_PITCH, "To pitch"); K(vm, P.LFO_FILTER, "To filter"); K(vm, P.LFO_PWM, "To width")
        }
        Section("Voices", Cream) {
            K(vm, P.PORTA, "Glide"); T(vm, P.GLIDE_POLY, "Poly"); T(vm, P.UNISON, "Unison")
            K(vm, P.UNI_DETUNE, "Spread"); K(vm, P.VOLUME, "Volume")
        }
    }
}

@Composable
private fun TopBar(vm: SynthViewModel) {
    val glow = vm.ui.glow
    Row(
        Modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xFF5C3F2A), Walnut, WalnutDark)))
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "Oberjein", fontSize = 17.sp, fontWeight = FontWeight.Black, color = Cream,
            style = TextStyle(shadow = Shadow(Amber.copy(alpha = 0.8f * glow), blurRadius = 14f))
        )
        Spacer(Modifier.width(10.dp))
        BarButton("<", { vm.loadPreset(vm.presetIndex - 1) })
        Box(Modifier.widthIn(min = 110.dp, max = 160.dp).height(30.dp).inset(RoundedCornerShape(5.dp)), contentAlignment = Alignment.Center) {
            Text(
                vm.currentName, maxLines = 1, textAlign = TextAlign.Center,
                style = TextStyle(color = Amber, fontSize = 13.sp, fontWeight = FontWeight.Bold, shadow = Shadow(Amber.copy(alpha = 0.7f * glow), blurRadius = 10f))
            )
        }
        BarButton(">", { vm.loadPreset(vm.presetIndex + 1) })
        Spacer(Modifier.width(10.dp))
        BarButton("Undo", { vm.undo() }, enabled = vm.canUndo)
        BarButton("Redo", { vm.redo() }, enabled = vm.canRedo)
        Spacer(Modifier.width(10.dp))
        BarButton("ARP", { vm.toggle(P.ARP_ON) }, active = vm.values[P.ARP_ON] > 0.5f, accent = Mint, led = true)
        BarButton("Panic", { vm.panic() })
    }
}
