package com.oberjein.synth

import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiInputPort
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList

/**
 * MIDI in and out.
 *  In : USB / Bluetooth devices, other apps' virtual ports, and our own virtual port (OberjeinMidiService).
 *       Notes, pitch bend, CC1 mod wheel, CC20-23 macros 1-4, CC64 hold, CC123 panic, MIDI clock + start/stop/continue.
 *  Out: arp/keyboard notes, optional 24 ppqn clock, to every connected device and to apps listening on our virtual port.
 */
class MidiIo(private val context: Context, private val vm: SynthViewModel) {
    private val main = Handler(Looper.getMainLooper())
    private var manager: MidiManager? = null

    private class Link(
        val id: Int, val name: String, val device: MidiDevice,
        val ins: List<MidiOutputPort>,      // device -> us
        val out: MidiInputPort?,            // us -> device
    )

    private val links = CopyOnWriteArrayList<Link>()
    private val opening = HashSet<Int>()
    @Volatile private var running = false
    private var pump: Thread? = null

    private val deviceCallback = object : MidiManager.DeviceCallback() {
        override fun onDeviceAdded(device: MidiDeviceInfo) { open(device) }
        override fun onDeviceRemoved(device: MidiDeviceInfo) { close(device.id) }
    }

    private val receiver = object : MidiReceiver() {
        override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) { parse(msg, offset, count) }
    }

    @Suppress("DEPRECATION")
    fun start() {
        running = true
        MidiBridge.sink = { m, o, c -> parse(m, o, c) }
        startPump()
        if (!context.packageManager.hasSystemFeature(PackageManager.FEATURE_MIDI)) {
            vm.midiStatus = "MIDI: not supported on this device"
            return
        }
        val m = context.getSystemService(Context.MIDI_SERVICE) as? MidiManager ?: return
        manager = m
        m.registerDeviceCallback(deviceCallback, main)
        m.devices.forEach { open(it) }
        updateStatus()
    }

    fun stop() {
        running = false
        MidiBridge.sink = null
        pump?.interrupt(); pump = null
        manager?.unregisterDeviceCallback(deviceCallback)
        manager = null
        links.forEach { release(it) }
        links.clear()
        opening.clear()
    }

    @Suppress("DEPRECATION")
    private fun isSelf(info: MidiDeviceInfo): Boolean {
        val si = info.properties.getParcelable<ServiceInfo>(MidiDeviceInfo.PROPERTY_SERVICE_INFO)
        return si?.packageName == context.packageName
    }

    private fun open(info: MidiDeviceInfo) {
        if (isSelf(info) || !opening.add(info.id)) return
        if (info.outputPortCount == 0 && info.inputPortCount == 0) return
        val name = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "MIDI device ${info.id}"
        manager?.openDevice(info, { device ->
            if (device == null) { opening.remove(info.id); return@openDevice }
            val ins = (0 until info.outputPortCount).mapNotNull { idx ->
                device.openOutputPort(idx)?.also { it.connect(receiver) }
            }
            val out = if (info.inputPortCount > 0) device.openInputPort(0) else null
            if (ins.isEmpty() && out == null) {
                device.close(); opening.remove(info.id)
            } else {
                links += Link(info.id, name, device, ins, out)
                updateStatus()
            }
        }, main)
    }

    private fun close(id: Int) {
        opening.remove(id)
        links.filter { it.id == id }.forEach { release(it); links.remove(it) }
        updateStatus()
    }

    private fun release(l: Link) {
        l.ins.forEach { runCatching { it.disconnect(receiver); it.close() } }
        runCatching { l.out?.close() }
        runCatching { l.device.close() }
    }

    private fun updateStatus() {
        val inNames = links.filter { it.ins.isNotEmpty() }.map { it.name }
        val outNames = links.filter { it.out != null }.map { it.name }
        main.post {
            vm.midiStatus = "In: " + (inNames.joinToString().ifEmpty { "-" }) +
                "\nOut: " + (outNames.joinToString().ifEmpty { "-" })
        }
    }

    // ---------------------------------------------------------------- in

    private fun parse(msg: ByteArray, offset: Int, count: Int) {
        val chSel = enumIndex(vm.values[P.MIDI_IN_CH], 17)       // 0 = omni, 1..16
        var i = offset
        val end = offset + count
        while (i < end) {
            val status = msg[i].toInt() and 0xFF
            if (status < 0x80) { i++; continue }
            val kind = status and 0xF0
            val len = when (kind) { 0xC0, 0xD0 -> 2; 0xF0 -> 1; else -> 3 }
            if (i + len > end) break
            val d1 = if (len > 1) msg[i + 1].toInt() and 0x7F else 0
            val d2 = if (len > 2) msg[i + 2].toInt() and 0x7F else 0
            if (kind == 0xF0) {
                when (status) {
                    0xF8 -> SynthEngine.nativeClockTick()
                    0xFA -> SynthEngine.nativeTransport(1)
                    0xFB -> SynthEngine.nativeTransport(2)
                    0xFC -> SynthEngine.nativeTransport(0)
                }
            } else if (chSel == 0 || (status and 0x0F) == chSel - 1) {
                when (kind) {
                    0x90 -> if (d2 > 0) vm.noteOn(d1, d2 / 127f) else vm.noteOff(d1)
                    0x80 -> vm.noteOff(d1)
                    0xE0 -> vm.pitchBend((((d2 shl 7) or d1) - 8192) / 8192f)
                    0xB0 -> when (d1) {
                        1 -> SynthEngine.nativeModWheel(d2 / 127f)
                        in 20..23 -> main.post { vm.setExternal(P.MACRO1 + (d1 - 20), d2 / 127f) }
                        64 -> main.post { vm.setExternal(P.ARP_HOLD, if (d2 >= 64) 1f else 0f) }
                        123 -> vm.panic()
                    }
                }
            }
            i += len
        }
    }

    // ---------------------------------------------------------------- out

    private fun startPump() {
        if (pump != null) return
        pump = Thread {
            val buf = IntArray(256)
            val bytes = ByteArray(256 * 3)
            while (running) {
                val n = SynthEngine.nativeDrainMidiOut(buf)
                if (n == 0) {
                    try { Thread.sleep(2) } catch (e: InterruptedException) { break }
                    continue
                }
                var len = 0
                for (k in 0 until n) {
                    val v = buf[k]
                    val st = (v shr 16) and 0xFF
                    bytes[len++] = st.toByte()
                    if (st < 0xF8) {
                        bytes[len++] = ((v shr 8) and 0x7F).toByte()
                        if ((st and 0xF0) != 0xC0 && (st and 0xF0) != 0xD0) bytes[len++] = (v and 0x7F).toByte()
                    }
                }
                send(bytes, len)
            }
        }.apply { name = "oberjein-midi-out"; isDaemon = true; start() }
    }

    private fun send(bytes: ByteArray, len: Int) {
        for (l in links) l.out?.let { runCatching { it.send(bytes, 0, len) } }
        MidiBridge.service?.outputPortReceivers?.firstOrNull()?.let { runCatching { it.send(bytes, 0, len) } }
    }
}
