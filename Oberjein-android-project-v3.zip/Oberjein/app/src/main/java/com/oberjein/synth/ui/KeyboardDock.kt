package com.oberjein.synth.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.oberjein.synth.P
import com.oberjein.synth.SynthViewModel

/**
 * Everything under the tab content: a drag handle (resizes the keyboard), the HOLD / octave / key-width / hide
 * strip, then pitch + mod wheels on the left of the keys.
 */
@Composable
fun KeyboardDock(vm: SynthViewModel) {
    val ui = vm.ui
    Column(Modifier.fillMaxWidth().background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Walnut, WalnutDark)))) {
        // drag handle ("haste"): drag up = taller keyboard
        Box(
            Modifier.fillMaxWidth().height(16.dp).pointerInput(Unit) {
                detectVerticalDragGestures(onDragEnd = { vm.saveUi() }) { change, dy ->
                    change.consume()
                    ui.setHeight(ui.heightDp - dy / density)
                }
            },
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.width(64.dp).height(5.dp).relief(RoundedCornerShape(3.dp), FaceTop, FaceBottom))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            BarButton("HOLD", { vm.toggle(P.ARP_HOLD) }, active = vm.values[P.ARP_HOLD] > 0.5f, accent = Mint, led = true)
            Spacer(Modifier.width(8.dp))
            Text("OCT", fontSize = 10.sp, color = Dim)
            BarButton("-", { vm.shiftOctave(-1) })
            Text("${vm.octave}", fontSize = 13.sp, color = Cream)
            BarButton("+", { vm.shiftOctave(1) })
            Spacer(Modifier.width(8.dp))
            Text("KEYS", fontSize = 10.sp, color = Dim)
            BarButton("-", { ui.setKeyWidth(ui.keyWidthDp - 4f); vm.saveUi() })
            Text("${ui.keyWidthDp.toInt()}", fontSize = 12.sp, color = Cream)
            BarButton("+", { ui.setKeyWidth(ui.keyWidthDp + 4f); vm.saveUi() })
            Spacer(Modifier.weight(1f))
            BarButton(if (ui.keyboardVisible) "Hide keys" else "Show keys", { ui.keyboardVisible = !ui.keyboardVisible; vm.saveUi() }, active = !ui.keyboardVisible)
        }
        if (ui.keyboardVisible) {
            Row(Modifier.fillMaxWidth().height(ui.heightDp.dp).padding(horizontal = 6.dp, vertical = 4.dp)) {
                if (ui.showWheels) {
                    Wheel("BEND", Sky, springBack = true, onChange = { vm.pitchBend(it * 2f - 1f) }, modifier = Modifier.fillMaxHeight())
                    Wheel("MOD", Amber, springBack = false, onChange = { vm.setModWheel(it) }, modifier = Modifier.fillMaxHeight().padding(start = 4.dp))
                    Spacer(Modifier.width(6.dp))
                }
                BoxWithConstraints(Modifier.weight(1f).fillMaxHeight()) {
                    val keys = (maxWidth.value / ui.keyWidthDp).toInt().coerceIn(7, 28)
                    Keyboard(
                        firstNote = vm.firstNote, whiteKeys = keys,
                        onNoteOn = { n, v -> vm.noteOn(n, v) }, onNoteOff = { n -> vm.noteOff(n) },
                        modifier = Modifier.fillMaxWidth().fillMaxHeight()
                    )
                }
            }
        }
    }
}
