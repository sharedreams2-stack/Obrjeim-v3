package com.oberjein.synth.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** 0..1 global glow strength (Settings > Display). */
val LocalGlow = compositionLocalOf { 1f }

/** Raised (or pressed-in) surface: vertical gradient plus a light top edge and dark bottom edge. */
fun Modifier.relief(shape: Shape, top: Color, bottom: Color, pressed: Boolean = false): Modifier =
    this.background(Brush.verticalGradient(if (pressed) listOf(bottom, top) else listOf(top, bottom)), shape)
        .border(
            1.dp,
            Brush.verticalGradient(if (pressed) listOf(Color(0x88000000), Color(0x33FFFFFF)) else listOf(Color(0x66FFFFFF), Color(0x99000000))),
            shape
        )

/** Recessed display / slot. */
fun Modifier.inset(shape: Shape): Modifier =
    this.background(Brush.verticalGradient(listOf(Color(0xFF08090A), Color(0xFF16171A))), shape)
        .border(1.dp, Brush.verticalGradient(listOf(Color(0xCC000000), Color(0x40FFFFFF))), shape)

/** Soft colored halo drawn behind the element (layered translucent rounded rects, cheap and API-independent). */
fun Modifier.glow(color: Color, strength: Float, radius: Dp = 10.dp, corner: Dp = 6.dp): Modifier =
    if (strength <= 0.01f) this else this.drawBehind {
        val r = radius.toPx()
        val steps = 5
        for (i in steps downTo 1) {
            val e = r * i / steps
            drawRoundRect(
                color.copy(alpha = 0.085f * strength * (steps - i + 1) / steps),
                Offset(-e, -e), Size(size.width + 2 * e, size.height + 2 * e), CornerRadius(corner.toPx() + e)
            )
        }
    }

/** Round LED with a lens highlight; glows when lit. */
@Composable
fun Led(on: Boolean, color: Color, size: Dp = 9.dp) {
    val g = LocalGlow.current
    Canvas(Modifier.size(size)) {
        val c = center
        val r = this.size.minDimension / 2f
        if (on && g > 0.01f) {
            drawCircle(Brush.radialGradient(listOf(color.copy(alpha = 0.6f * g), Color.Transparent), c, r * 2.8f), r * 2.8f, c)
        }
        val hi = c - Offset(r * 0.3f, r * 0.35f)
        drawCircle(
            Brush.radialGradient(
                if (on) listOf(Color.White.copy(alpha = 0.95f), color, color.copy(alpha = 0.65f))
                else listOf(Color(0xFF50535A), Color(0xFF26282C), Color(0xFF111214)),
                hi, r * 1.5f
            ), r, c
        )
        drawCircle(Color.Black.copy(alpha = 0.7f), r, c, style = Stroke(1f))
    }
}

/** Tiny rivet used on panel corners. */
@Composable
fun Rivet(size: Dp = 5.dp) {
    Canvas(Modifier.size(size)) {
        val r = this.size.minDimension / 2f
        drawCircle(Brush.radialGradient(listOf(Color(0xFF6A6D75), Color(0xFF1B1C1F)), center - Offset(r * 0.3f, r * 0.3f), r * 1.4f), r, center)
    }
}
