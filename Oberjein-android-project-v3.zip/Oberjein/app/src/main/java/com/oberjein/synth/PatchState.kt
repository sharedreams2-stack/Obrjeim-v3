package com.oberjein.synth

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ModSlot(val src: Int = 0, val dst: Int = 0, val amt: Float = 0f)

/** Default matrix: mod wheel -> LFO 1 pitch depth (the classic vibrato wheel). */
fun defaultMods(): List<ModSlot> = List(MOD_SLOTS) { if (it == 0) ModSlot(5, P.LFO_PITCH, 1f) else ModSlot() }

/** Everything needed to restore a sound: all params, the 64-stage lane and the mod matrix. */
class PatchState(
    val name: String,
    val values: FloatArray,
    val lane: LongArray,
    val mods: List<ModSlot>,
    val preset: Int = 0,
    val octave: Int = 3,
) {
    fun sameContent(o: PatchState) = values.contentEquals(o.values) && lane.contentEquals(o.lane) && mods == o.mods
}

/** JSON patch format. Params are stored by key (not by index) so files survive parameter reordering. */
object PatchJson {
    private const val FORMAT = "oberjein-patch"
    private const val VERSION = 2

    fun toJson(s: PatchState): JSONObject {
        val params = JSONObject()
        PARAM_INFO.forEachIndexed { i, info -> params.put(info.key, s.values[i].toDouble()) }
        val lane = JSONArray()
        s.lane.forEach { lane.put(it) }
        val mods = JSONArray()
        s.mods.forEach { m ->
            mods.put(JSONObject().put("src", m.src).put("dst", PARAM_INFO.getOrNull(m.dst)?.key ?: "").put("amt", m.amt.toDouble()))
        }
        return JSONObject()
            .put("format", FORMAT).put("version", VERSION).put("name", s.name)
            .put("preset", s.preset).put("octave", s.octave)
            .put("params", params).put("lane", lane).put("mods", mods)
    }

    fun encode(s: PatchState): String = toJson(s).toString(2)

    fun encodeBundle(list: List<PatchState>): String {
        val arr = JSONArray()
        list.forEach { arr.put(toJson(it)) }
        return JSONObject().put("format", "oberjein-bundle").put("version", VERSION).put("patches", arr).toString(2)
    }

    fun fromJson(o: JSONObject): PatchState? {
        if (o.optString("format") != FORMAT) return null
        val values = DEFAULTS.copyOf()
        val params = o.optJSONObject("params") ?: return null
        PARAM_INFO.forEachIndexed { i, info ->
            if (params.has(info.key)) values[i] = params.optDouble(info.key, values[i].toDouble()).toFloat().coerceIn(0f, 1f)
        }
        val lane = LongArray(Lane.STEPS) { DEFAULT_STEP }
        o.optJSONArray("lane")?.let { a -> for (i in 0 until minOf(a.length(), Lane.STEPS)) lane[i] = a.optLong(i, DEFAULT_STEP) }
        val mods = MutableList(MOD_SLOTS) { ModSlot() }
        o.optJSONArray("mods")?.let { a ->
            for (i in 0 until minOf(a.length(), MOD_SLOTS)) {
                val m = a.optJSONObject(i) ?: continue
                val dst = PARAM_INFO.indexOfFirst { it.key == m.optString("dst") }
                val src = m.optInt("src", 0)
                mods[i] = if (dst >= 0 && src in 1 until MOD_SOURCES.size)
                    ModSlot(src, dst, m.optDouble("amt", 0.0).toFloat().coerceIn(-1f, 1f)) else ModSlot()
            }
        }
        return PatchState(
            o.optString("name", "Imported"), values, lane, mods,
            o.optInt("preset", 0).coerceIn(0, PRESETS.size - 1), o.optInt("octave", 3).coerceIn(1, 6)
        )
    }

    /** Accepts a single patch or a bundle. Returns null when the text is not an Oberjein file. */
    fun decode(text: String): List<PatchState>? = try {
        val o = JSONObject(text)
        if (o.optString("format") == "oberjein-bundle") {
            val a = o.getJSONArray("patches")
            (0 until a.length()).mapNotNull { fromJson(a.getJSONObject(it)) }.ifEmpty { null }
        } else {
            fromJson(o)?.let { listOf(it) }
        }
    } catch (e: Exception) {
        null
    }
}

/** Patches live in filesDir/patches (covered by Android auto-backup); the working state is autosaved. */
class PatchStore(context: Context) {
    private val dir = File(context.filesDir, "patches").apply { mkdirs() }
    private val auto = File(context.filesDir, "autosave.json")

    fun clean(name: String): String = name.replace(Regex("[^\\p{L}\\p{N} _.-]"), "").trim().take(40)

    private fun file(name: String) = File(dir, clean(name) + ".json")

    fun names(): List<String> = dir.listFiles { f -> f.extension == "json" }?.map { it.nameWithoutExtension }?.sortedBy { it.lowercase() } ?: emptyList()

    fun save(name: String, s: PatchState): Boolean {
        if (clean(name).isEmpty()) return false
        return runCatching { file(name).writeText(PatchJson.encode(PatchState(clean(name), s.values, s.lane, s.mods, s.preset, s.octave))) }.isSuccess
    }

    fun load(name: String): PatchState? = runCatching { PatchJson.decode(file(name).readText())?.firstOrNull() }.getOrNull()

    fun delete(name: String) { file(name).delete() }

    fun saveAuto(s: PatchState) { runCatching { auto.writeText(PatchJson.encode(s)) } }

    fun loadAuto(): PatchState? = runCatching { if (auto.exists()) PatchJson.decode(auto.readText())?.firstOrNull() else null }.getOrNull()
}
