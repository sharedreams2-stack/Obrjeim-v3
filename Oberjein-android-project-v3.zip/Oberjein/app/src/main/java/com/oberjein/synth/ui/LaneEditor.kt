package com.oberjein.synth.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.oberjein.synth.Lane
import com.oberjein.synth.SynthViewModel
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private const val COLS = 32   // 64 stages drawn as 2 rows of 32

/**
 * Paint-style editor for one lane of the 64-stage loop. Drag across stages to draw values;
 * on the On/Tie lane a tap cycles Off -> On -> Tie and dragging paints that state.
 * Stages past the loop length are dimmed; the playhead is outlined.
 */
@Composable
fun LaneEditor(vm: SynthViewModel, laneId: Int, modifier: Modifier = Modifier) {
    val tint = LocalTint.current
    val len = vm.arpLength()
    val playhead = vm.playhead

    Canvas(
        modifier.pointerInput(laneId) {
            awaitEachGesture {
                val down = awaitFirstDown()
                val gap = 6.dp.toPx()
                var paint: Int? = null            // On/Tie lane: 0 off, 1 on, 2 tie

                fun apply(pos: Offset) {
                    val rowH = (size.height - gap) / 2f
                    val row = if (pos.y < rowH + gap / 2f) 0 else 1
                    val col = (pos.x / (size.width / COLS)).toInt().coerceIn(0, COLS - 1)
                    val i = row * COLS + col
                    val frac = 1f - (pos.y - row * (rowH + gap)).coerceIn(0f, rowH) / rowH
                    val s = vm.step(i)
                    val n = when (laneId) {
                        Lane.PITCH -> s.copy(pitch = ((frac - 0.5f) * 48f).roundToInt().coerceIn(-24, 24))
                        Lane.VEL -> s.copy(vel = (frac * 127f).roundToInt().coerceIn(1, 127))
                        Lane.GATE -> s.copy(gate = (frac * 127f).roundToInt().coerceIn(5, 127))
                        Lane.PROB -> s.copy(prob = (frac * 100f).roundToInt().coerceIn(0, 100))
                        Lane.RATCH -> s.copy(ratch = ((frac * 8f).toInt() + 1).coerceIn(1, 8))
                        Lane.ON -> {
                            val p = paint ?: (((if (!s.on) 0 else if (s.tie) 2 else 1) + 1) % 3).also { paint = it }
                            s.copy(on = p != 0, tie = p == 2)
                        }
                        else -> s.copy(mod = (frac * 127f).roundToInt().coerceIn(0, 127))
                    }
                    vm.setStep(i, n)
                }

                apply(down.position)
                down.consume()
                do {
                    val event = awaitPointerEvent()
                    event.changes.forEach { if (it.pressed) apply(it.position); it.consume() }
                } while (event.changes.any { it.pressed })
                vm.commit()
            }
        }
    ) {
        val gap = 6.dp.toPx()
        val rowH = (size.height - gap) / 2f
        val cw = size.width / COLS
        for (i in 0 until Lane.STEPS) {
            val row = i / COLS
            val x = (i % COLS) * cw
            val y0 = row * (rowH + gap)
            val inLoop = i < len
            val beat = ((i % COLS) / 4) % 2 == 0
            drawRect(
                if (!inLoop) Color(0xFF17181A) else if (beat) Color(0xFF292B30) else Color(0xFF212328),
                Offset(x + 1f, y0), Size(cw - 2f, rowH)
            )
            val s = vm.step(i)
            val a = (if (inLoop) 1f else 0.35f) * (if (s.on || laneId == Lane.ON) 1f else 0.45f)
            val c = tint.copy(alpha = a)
            when (laneId) {
                Lane.PITCH -> bar(x, y0, cw, rowH, 0.5f, (s.pitch.coerceIn(-24, 24) + 24) / 48f, c)
                Lane.VEL -> bar(x, y0, cw, rowH, 0f, s.vel / 127f, c)
                Lane.GATE -> bar(x, y0, cw, rowH, 0f, s.gate / 127f, c)
                Lane.PROB -> bar(x, y0, cw, rowH, 0f, s.prob / 100f, c)
                Lane.RATCH -> bar(x, y0, cw, rowH, 0f, s.ratch / 8f, c)
                Lane.ON -> if (s.on) {
                    bar(x, y0, cw, rowH, 0f, 1f, if (s.tie) Color(0xFFEDE6D6).copy(alpha = a) else c)
                }
                else -> bar(x, y0, cw, rowH, 0.5f, s.mod / 127f, c)
            }
            if (i == playhead) {
                drawRect(Color(0xFFEDE6D6), Offset(x + 1f, y0), Size(cw - 2f, rowH), style = Stroke(2.dp.toPx()))
            }
        }
    }
}

private fun DrawScope.bar(x: Float, y0: Float, cw: Float, rowH: Float, from: Float, to: Float, color: Color) {
    val top = y0 + rowH * (1f - max(from, to))
    val h = max(2.dp.toPx(), rowH * abs(to - from))
    drawRect(Brush.verticalGradient(listOf(color, color.copy(alpha = color.alpha * 0.55f)), startY = top, endY = top + h), Offset(x + 2f, min(top, y0 + rowH - h)), Size(cw - 4f, h))
}
