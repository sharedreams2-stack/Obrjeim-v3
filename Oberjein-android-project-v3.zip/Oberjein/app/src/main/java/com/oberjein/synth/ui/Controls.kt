package com.oberjein.synth.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.oberjein.synth.DEFAULTS
import com.oberjein.synth.PARAM_INFO
import com.oberjein.synth.SynthViewModel
import com.oberjein.synth.enumIndex
import com.oberjein.synth.enumValue
import com.oberjein.synth.formatParam

/** Knob bound to a parameter: drag = live, release = one undo step, double-tap = default. */
@Composable
fun K(vm: SynthViewModel, id: Int, label: String = PARAM_INFO[id].label) =
    Knob(
        label, vm.values[id], { vm.set(id, it) },
        resetTo = DEFAULTS[id], valueText = { formatParam(id, it) }, onFinished = { vm.commit() }
    )

/** On/off switch bound to a parameter. */
@Composable
fun T(vm: SynthViewModel, id: Int, label: String = PARAM_INFO[id].label) =
    Toggle(label, vm.values[id] > 0.5f, { vm.setNow(id, if (it) 1f else 0f) })

/** Drop-down bound to an enumerated parameter (value = index / (count - 1)). */
@Composable
fun E(vm: SynthViewModel, id: Int, options: List<String>, label: String = PARAM_INFO[id].label, width: Dp = 78.dp) =
    Picker(
        label, options, enumIndex(vm.values[id], options.size),
        { vm.setNow(id, enumValue(it, options.size)) }, width = width
    )
