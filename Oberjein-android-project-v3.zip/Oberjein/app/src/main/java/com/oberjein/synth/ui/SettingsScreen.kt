package com.oberjein.synth.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.oberjein.synth.Names
import com.oberjein.synth.P
import com.oberjein.synth.SynthViewModel
import kotlin.math.roundToInt

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, text: String, tint: Color, onChange: (Float) -> Unit, onDone: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 12.sp, color = Cream, modifier = Modifier.width(110.dp))
        Slider(
            value, onChange, Modifier.weight(1f), valueRange = range, onValueChangeFinished = onDone,
            colors = SliderDefaults.colors(thumbColor = tint, activeTrackColor = tint, inactiveTrackColor = Track)
        )
        Text(text, fontSize = 12.sp, color = tint, modifier = Modifier.width(64.dp).padding(start = 8.dp))
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsTab(vm: SynthViewModel) {
    val ui = vm.ui
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 4.dp)) {
        Panel("Keyboard", Mint, Modifier.fillMaxWidth()) {
            SliderRow("Keyboard height", ui.heightDp, 56f..260f, "${ui.heightDp.roundToInt()} dp", Mint, { ui.setHeight(it) }, { vm.saveUi() })
            SliderRow("Key width", ui.keyWidthDp, 24f..90f, "${ui.keyWidthDp.roundToInt()} dp", Mint, { ui.setKeyWidth(it) }, { vm.saveUi() })
            FlowRow {
                Chip("Keyboard visible", ui.keyboardVisible, { ui.keyboardVisible = !ui.keyboardVisible; vm.saveUi() })
                Chip("Pitch + mod wheels", ui.showWheels, { ui.showWheels = !ui.showWheels; vm.saveUi() })
            }
            Text("Tip: drag the bar above HOLD to resize the keyboard while playing.", fontSize = 10.sp, color = Dim, modifier = Modifier.padding(top = 4.dp))
        }
        Panel("Sound engine", Amber, Modifier.fillMaxWidth()) {
            FlowRow {
                K(vm, P.BEND_RANGE); K(vm, P.MASTER_TUNE)
                T(vm, P.GLIDE_POLY, "Poly glide")
            }
        }
        Panel("Display", Iris, Modifier.fillMaxWidth()) {
            SliderRow("Glow / LEDs", ui.glow, 0f..1f, "${(ui.glow * 100).roundToInt()}%", Iris, { ui.setGlowValue(it) }, { vm.saveUi() })
            BarButton("Reset interface", { ui.reset() })
        }
        Panel("MIDI", Teal, Modifier.fillMaxWidth()) {
            FlowRow {
                T(vm, P.MIDI_OUT, "Send notes"); E(vm, P.MIDI_OUT_CH, Names.CHANNELS, "Out channel")
                T(vm, P.MIDI_CLK_OUT, "Send clock"); E(vm, P.MIDI_IN_CH, Names.IN_CHANNELS, "In channel")
            }
            Text(vm.midiStatus, fontSize = 11.sp, color = Cream, modifier = Modifier.padding(top = 4.dp))
            Text(
                "Other apps: pick \"Oberjein Synth\" as MIDI input to play it, or as output to receive its notes and clock " +
                    "(keep Oberjein open). Arp clock = \"MIDI clock\" follows Start/Stop/Clock from the host.\n" +
                    "CC 1 mod wheel, 20-23 macros 1-4, 64 hold, 123 panic.",
                fontSize = 10.sp, color = Dim, modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}
