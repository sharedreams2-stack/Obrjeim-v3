package com.oberjein.synth

import android.media.midi.MidiDeviceService
import android.media.midi.MidiReceiver

/** Shared hooks between the system-bound MIDI service and the running app (same process). */
object MidiBridge {
    /** Set by [MidiIo] while the app is in the foreground: parses bytes arriving from other apps. */
    @Volatile var sink: ((ByteArray, Int, Int) -> Unit)? = null

    /** Alive while some other app has our virtual port open; used to send MIDI out to it. */
    @Volatile var service: MidiDeviceService? = null
}

/**
 * Virtual MIDI device "Oberjein Synth": other apps (DAWs, sequencers, other synths) list it
 * as an input (to play Oberjein) and as an output (to receive Oberjein's arp notes and clock).
 */
class OberjeinMidiService : MidiDeviceService() {
    private val receiver = object : MidiReceiver() {
        override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
            MidiBridge.sink?.invoke(msg, offset, count)
        }
    }

    override fun onCreate() {
        super.onCreate()
        MidiBridge.service = this
    }

    override fun onDestroy() {
        MidiBridge.service = null
        super.onDestroy()
    }

    override fun onGetInputPortReceivers(): Array<MidiReceiver> = arrayOf(receiver)
}
