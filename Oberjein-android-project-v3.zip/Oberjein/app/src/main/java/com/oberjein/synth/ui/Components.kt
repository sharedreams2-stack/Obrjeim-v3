package com.oberjein.synth.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.FlowRowScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

private val CELL_H = 62.dp      // every knob / picker / toggle cell has the same height so rows line up
private val FACE_H = 44.dp      // the control itself is centered in this band

/** Standard grid cell: control centered in a fixed band, optional caption underneath. */
@Composable
private fun Cell(width: Dp, caption: String?, captionColor: Color = Dim, control: @Composable () -> Unit) {
    Column(Modifier.width(width).height(CELL_H), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.height(FACE_H).fillMaxWidth(), contentAlignment = Alignment.Center) { control() }
        Text(caption ?: "", fontSize = 10.sp, color = captionColor, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
    }
}

/** Shared pressable face: relief, tint when lit, glow, and a small squash + inset while pressed. */
@Composable
private fun Face(
    modifier: Modifier, onClick: () -> Unit, tint: Color, lit: Boolean, enabled: Boolean = true,
    shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(6.dp),
    content: @Composable () -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.95f else 1f, label = "press")
    val glow = LocalGlow.current
    val top = lerp(FaceTop, tint, if (lit) 0.5f else 0f).let { if (pressed) lerp(it, Color.Black, 0.25f) else it }
    val bottom = lerp(FaceBottom, tint, if (lit) 0.22f else 0f).let { if (pressed) lerp(it, Color.Black, 0.25f) else it }
    Box(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .glow(tint, if (lit || pressed) glow else 0f, 8.dp, 6.dp)
            .relief(shape, top, bottom, pressed)
            .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

/** Rotary knob: 3D cap with a glowing value ring. Drag up/down, double-tap to reset; value shows while dragging. */
@Composable
fun Knob(
    label: String,
    value: Float,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    diameter: Dp = 42.dp,
    resetTo: Float? = null,
    valueText: ((Float) -> String)? = null,
    onFinished: () -> Unit = {},
) {
    val tint = LocalTint.current
    val glow = LocalGlow.current
    val current by rememberUpdatedState(value)
    val callback by rememberUpdatedState(onChange)
    val finished by rememberUpdatedState(onFinished)
    val reset by rememberUpdatedState(resetTo)
    var dragging by remember { mutableStateOf(false) }
    Box(modifier) {
        Cell(58.dp, if (dragging && valueText != null) valueText(current) else label, if (dragging) tint else Dim) {
            Canvas(
                Modifier.size(diameter)
                    .pointerInput(Unit) { detectTapGestures(onDoubleTap = { reset?.let { callback(it); finished() } }) }
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onDragStart = { dragging = true },
                            onDragEnd = { dragging = false; finished() },
                            onDragCancel = { dragging = false; finished() },
                        ) { change, dragAmount ->
                            change.consume()
                            callback((current - dragAmount / 260f).coerceIn(0f, 1f))
                        }
                    }
            ) {
                val s = size.minDimension
                val sw = 3.5.dp.toPx()
                val tl = Offset(sw, sw)
                val arc = Size(s - 2 * sw, s - 2 * sw)
                drawArc(Color(0xFF08090A), 135f, 270f, false, tl, arc, style = Stroke(sw + 2.dp.toPx(), cap = StrokeCap.Round))
                drawArc(Track, 135f, 270f, false, tl, arc, style = Stroke(sw, cap = StrokeCap.Round))
                if (current > 0.005f) {
                    if (glow > 0.01f) drawArc(tint.copy(alpha = (if (dragging) 0.4f else 0.25f) * glow), 135f, 270f * current, false, tl, arc, style = Stroke(sw * 2.8f, cap = StrokeCap.Round))
                    drawArc(tint, 135f, 270f * current, false, tl, arc, style = Stroke(sw, cap = StrokeCap.Round))
                }
                val c = center
                val capR = s / 2f - sw * 2.3f
                drawCircle(Color(0x99000000), capR, c + Offset(0f, 2.dp.toPx()))
                drawCircle(
                    Brush.radialGradient(listOf(Color(0xFF787B85), Color(0xFF34363C), Color(0xFF131417)), c - Offset(capR * 0.35f, capR * 0.45f), capR * 1.7f),
                    capR, c
                )
                drawCircle(Brush.verticalGradient(listOf(Color(0x77FFFFFF), Color(0x11000000))), capR, c, style = Stroke(1.2.dp.toPx()))
                val a = Math.toRadians((135f + 270f * current).toDouble())
                val dir = Offset(cos(a).toFloat(), sin(a).toFloat())
                if (glow > 0.01f) drawLine(tint.copy(alpha = 0.35f * glow), c + dir * (capR * 0.2f), c + dir * (capR * 0.85f), 6.dp.toPx(), StrokeCap.Round)
                drawLine(Color(0xFFF4EEDF), c + dir * (capR * 0.2f), c + dir * (capR * 0.85f), 2.2.dp.toPx(), StrokeCap.Round)
            }
        }
    }
}

/** Latching switch with an LED. */
@Composable
fun Toggle(label: String, on: Boolean, onChange: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    val tint = LocalTint.current
    Box(modifier) {
        Cell((label.length * 7 + 38).dp.coerceAtLeast(58.dp), null) {
            Face(Modifier, { onChange(!on) }, tint, on) {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Led(on, tint)
                    Spacer(Modifier.width(6.dp))
                    Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (on) Cream else Dim, maxLines = 1)
                }
            }
        }
    }
}

/** LCD-style drop-down for enumerated values. */
@Composable
fun Picker(
    label: String, options: List<String>, index: Int, onChange: (Int) -> Unit,
    modifier: Modifier = Modifier, width: Dp = 78.dp,
) {
    val tint = LocalTint.current
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        Cell(width, label) {
            Box {
                Box(
                    Modifier.fillMaxWidth().padding(horizontal = 3.dp).height(30.dp).inset(RoundedCornerShape(5.dp))
                        .clip(RoundedCornerShape(5.dp)).clickable { open = true },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        options[index.coerceIn(0, options.lastIndex)], maxLines = 1,
                        style = TextStyle(
                            color = tint, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                            shadow = Shadow(tint.copy(alpha = 0.7f * LocalGlow.current), blurRadius = 10f)
                        )
                    )
                }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    options.forEachIndexed { i, s ->
                        DropdownMenuItem(
                            text = { Text(s, color = if (i == index) tint else Cream, fontSize = 13.sp) },
                            onClick = { onChange(i); open = false }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, accent: Color? = null) {
    val tint = accent ?: LocalTint.current
    Face(
        modifier.padding(2.dp), onClick, tint, selected, shape = RoundedCornerShape(14.dp)
    ) {
        Text(
            label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
            color = if (selected) Cream else Dim, modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp)
        )
    }
}

@Composable
fun BarButton(label: String, onClick: () -> Unit, active: Boolean = false, enabled: Boolean = true, accent: Color = Amber, led: Boolean = false) {
    Face(Modifier.padding(horizontal = 3.dp), onClick, accent, active, enabled) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            if (led) { Led(active, accent); Spacer(Modifier.width(6.dp)) }
            Text(
                label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                color = if (active) Cream else if (enabled) Cream.copy(alpha = 0.85f) else Dim.copy(alpha = 0.6f)
            )
        }
    }
}

/** Title strip shared by Section and Panel: colored LED dot, caption, glowing underline. */
@Composable
private fun Header(title: String, tint: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Led(true, tint, 7.dp)
        Spacer(Modifier.width(6.dp))
        Text(
            title.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = tint, letterSpacing = 1.sp,
            style = TextStyle(shadow = Shadow(tint.copy(alpha = 0.5f * LocalGlow.current), blurRadius = 8f))
        )
    }
    Box(
        Modifier.padding(top = 3.dp, bottom = 3.dp).fillMaxWidth().height(2.dp).glow(tint, LocalGlow.current * 0.5f, 4.dp, 1.dp)
            .background(Brush.horizontalGradient(listOf(tint, tint.copy(alpha = 0.05f))))
    )
}

private fun Modifier.panelSkin() = this.padding(4.dp)
    .relief(RoundedCornerShape(8.dp), PanelTop, PanelBottom)

/** Wrapping group of controls under a colored legend; children pick up the color. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Section(title: String, tint: Color, content: @Composable FlowRowScope.() -> Unit) {
    CompositionLocalProvider(LocalTint provides tint) {
        Column(Modifier.panelSkin().padding(horizontal = 8.dp, vertical = 6.dp)) {
            Header(title, tint)
            FlowRow(verticalArrangement = androidx.compose.foundation.layout.Arrangement.Top, content = content)
        }
    }
}

/** Vertical group, can be full width. */
@Composable
fun Panel(title: String, tint: Color, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    CompositionLocalProvider(LocalTint provides tint) {
        Column(modifier.panelSkin().padding(horizontal = 8.dp, vertical = 6.dp)) {
            Header(title, tint)
            content()
        }
    }
}
