package com.oberjein.synth.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.oberjein.synth.MOD_SLOTS
import com.oberjein.synth.MOD_SOURCES
import com.oberjein.synth.ModSlot
import com.oberjein.synth.Names
import com.oberjein.synth.P
import com.oberjein.synth.PARAM_INFO
import com.oberjein.synth.SynthViewModel
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ModTab(vm: SynthViewModel) {
    var picking by remember { mutableStateOf<Int?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 4.dp)) {
        FlowRow {
            Section("Macros (CC 20-23)", Cream) {
                K(vm, P.MACRO1); K(vm, P.MACRO2); K(vm, P.MACRO3); K(vm, P.MACRO4)
            }
            Section("LFO 2", Iris) {
                E(vm, P.LFO2_WAVE, Names.LFO_SHAPES, "Shape", width = 70.dp); K(vm, P.LFO2_RATE)
            }
        }
        Panel("Modulation matrix: any source to any parameter", Sky, Modifier.fillMaxWidth()) {
            for (slot in 0 until MOD_SLOTS) ModRow(vm, slot) { picking = slot }
            Text(
                "Amount is added to the target's knob position (+-100% of its range). Arp targets work too: try Macro 1 > Tempo.",
                fontSize = 10.sp, color = Dim, modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
    picking?.let { slot ->
        DestinationDialog(
            onPick = { dst ->
                val m = vm.mods[slot]
                vm.setModNow(slot, m.copy(dst = dst, src = if (m.src == 0) 1 else m.src, amt = if (m.amt == 0f) 0.5f else m.amt))
                picking = null
            },
            onDismiss = { picking = null }
        )
    }
}

@Composable
private fun ModRow(vm: SynthViewModel, slot: Int, onPickTarget: () -> Unit) {
    val m = vm.mods[slot]
    val info = PARAM_INFO.getOrNull(m.dst)
    Row(Modifier.fillMaxWidth().padding(vertical = 1.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("${slot + 1}", fontSize = 11.sp, color = Dim, modifier = Modifier.width(16.dp))
        Picker("", MOD_SOURCES, m.src, { vm.setModNow(slot, vm.mods[slot].copy(src = it)) }, width = 100.dp)
        Spacer(Modifier.width(6.dp))
        Box(
            Modifier.weight(1f).clip(RoundedCornerShape(4.dp)).background(Track)
                .clickable(onClick = onPickTarget).padding(horizontal = 8.dp, vertical = 9.dp)
        ) {
            Text(
                if (m.src == 0 || info == null) "choose target..." else "${info.group} > ${info.label}",
                fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                color = if (m.src == 0) Dim else Sky
            )
        }
        Slider(
            value = m.amt,
            onValueChange = { vm.setMod(slot, vm.mods[slot].copy(amt = it)) },
            onValueChangeFinished = { vm.commit() },
            valueRange = -1f..1f,
            modifier = Modifier.width(170.dp).padding(horizontal = 6.dp),
            colors = SliderDefaults.colors(thumbColor = Sky, activeTrackColor = Sky, inactiveTrackColor = Track)
        )
        Text("%+d%%".format((m.amt * 100).roundToInt()), fontSize = 11.sp, color = Cream, modifier = Modifier.width(42.dp))
        Chip("clear", false, { vm.setModNow(slot, ModSlot()) })
    }
}

@Composable
private fun DestinationDialog(onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val groups = remember { PARAM_INFO.withIndex().filter { it.value.modulatable }.groupBy { it.value.group } }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxWidth(0.6f).fillMaxHeight(0.9f).clip(RoundedCornerShape(8.dp)).background(Panel)) {
            LazyColumn(Modifier.padding(12.dp)) {
                groups.forEach { (group, list) ->
                    item {
                        Text(group, color = Sky, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp, bottom = 2.dp))
                    }
                    items(list) { iv ->
                        Text(
                            iv.value.label, color = Cream, fontSize = 14.sp,
                            modifier = Modifier.fillMaxWidth().clickable { onPick(iv.index) }.padding(vertical = 8.dp, horizontal = 4.dp)
                        )
                    }
                }
            }
        }
    }
}
