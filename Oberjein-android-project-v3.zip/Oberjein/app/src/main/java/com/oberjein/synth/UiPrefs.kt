package com.oberjein.synth

import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Interface preferences (not part of a patch): keyboard size, wheels, glow. Persisted in SharedPreferences. */
class UiPrefs(private val sp: SharedPreferences) {
    var heightDp by mutableFloatStateOf(sp.getFloat("kbHeight", 96f)); private set
    var keyWidthDp by mutableFloatStateOf(sp.getFloat("keyW", 48f)); private set
    var keyboardVisible by mutableStateOf(sp.getBoolean("kbVisible", true))
    var showWheels by mutableStateOf(sp.getBoolean("wheels", true))
    var glow by mutableFloatStateOf(sp.getFloat("glow", 1f))

    fun setHeight(v: Float) { heightDp = v.coerceIn(56f, 260f) }
    fun setKeyWidth(v: Float) { keyWidthDp = v.coerceIn(24f, 90f) }
    fun setGlowValue(v: Float) { glow = v.coerceIn(0f, 1f) }

    fun save() {
        sp.edit().putFloat("kbHeight", heightDp).putFloat("keyW", keyWidthDp)
            .putBoolean("kbVisible", keyboardVisible).putBoolean("wheels", showWheels).putFloat("glow", glow).apply()
    }

    fun reset() { heightDp = 96f; keyWidthDp = 48f; keyboardVisible = true; showWheels = true; glow = 1f; save() }
}
